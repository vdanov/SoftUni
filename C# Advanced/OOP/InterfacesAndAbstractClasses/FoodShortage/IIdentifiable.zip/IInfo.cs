﻿namespace FoodShortage
{
    public interface IInfo
    {
        public string Name { get; set; }
        public int Age { get; set; }
        
    }
}