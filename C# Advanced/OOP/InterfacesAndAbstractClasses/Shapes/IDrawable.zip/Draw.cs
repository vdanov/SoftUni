﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public abstract class Draw
    {
        public virtual void Drawing() { Console.WriteLine("Default implementation"); }
    }
}