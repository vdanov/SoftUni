﻿namespace BorderControl
{
    public interface IIdentifiable
    {
        public string ID { get; set; }
    }
}