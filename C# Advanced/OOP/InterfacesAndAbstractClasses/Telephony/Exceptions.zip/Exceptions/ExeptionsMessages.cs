﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public class ExeptionsMessages
    {
        public static string InvalidNumberExeptionMessage = "Invalid number!";

        public static string InvalidUrlExeptionMessage = "Invalid URL!";
    }
}